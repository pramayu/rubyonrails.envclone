﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Contact_Manager_Client
{
    public partial class Form_CreateGroup : Form
    {
        public Form_CreateGroup()
        {
            InitializeComponent();
        }
    }
}
