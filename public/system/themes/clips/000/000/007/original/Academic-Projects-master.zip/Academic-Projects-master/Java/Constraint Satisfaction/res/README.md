Resource Files
==============

Everything in here is the Resource Files used for Input to the Program. Feel free to copy these and use them as examples. If you were to open the Project in the Eclipse IDE, you would specific the path to this files as `./res/<filename>`.
