Node -i 0 -l 120 -m "Message Sent Over" -d 5 -n 2 1 2 -D 1&
Node -i 1 -l 120 -n 2 0 2 -D 1&
Node -i 2 -l 120 -n 4 0 1 3 4 -D 1&
Node -i 3 -l 120 -n 3 2 4 6 -D 1&
Node -i 4 -l 120 -n 2 3 5 -D 1&
Node -i 6 -l 120 -n 2 3 5 -D 1&
