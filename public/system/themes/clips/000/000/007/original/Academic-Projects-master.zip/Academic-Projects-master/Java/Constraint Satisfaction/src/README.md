Source Files
============

Everything in here is the Source Files for Compiling, Managing, Editting, or What-Have-You to the Project.

**Assignment:**<br>
Everything in this Folder contains Implementation Specific Classes, and were created to satisfy the requirements of the Assignment.

**Constraint Satisfaction:**<br>
Everything in this Folder contains Abstract Classes, which were created to allow me to adapt this Project to handle different types of Constraint Satisfaction Problems in the future.
