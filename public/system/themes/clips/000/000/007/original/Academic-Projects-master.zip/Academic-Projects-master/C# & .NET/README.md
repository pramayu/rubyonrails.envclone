C#/.NET
-----

All projects are made using Visual Studio C# (2008+) and SQL Server (2008+).

**Contents:**
 - Contact Manager
