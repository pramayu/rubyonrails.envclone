//* Description *//
// Title: Definitions
// Author: Tyler Reed
// Defines Project Constants

//* Definitions *//
#define SIZE_BUFFER 100
#define SIZE_HOST 100
#define LIMIT_CLIENT 5
