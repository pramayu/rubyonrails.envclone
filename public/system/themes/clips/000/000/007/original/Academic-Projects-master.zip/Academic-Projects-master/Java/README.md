Java
-----

All Projects were made using the <a href="http://www.eclipse.org/downloads/">Eclipse (Helios+) IDE</a> and designed to run in a Windows Environment using Java 6 or later.

**Contents:**
 - Generic Best-First Search
 - Constraint Satisfaction
 - Knowledge Representation
 - Probabilistic Reasoning

***Note***: If you see a Directory not is not listed in the Contents, that is because the Project is still under construction, and is not meant to be viewed, downloaded, compiled, or ran. However, you're welcome to do any of that stuff.
