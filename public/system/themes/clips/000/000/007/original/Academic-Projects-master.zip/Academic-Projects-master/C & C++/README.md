C/C++
-----

All projects are designed to run using the **g++** compiler. Programs are tested in a Unix Environment, but should run fine in a Windows Environment. It is recommended that you compile and run these programs in a Bash Console.

I used <a href="http://www.netsarang.com/products/xsh_overview.html">XShell</a> for all my projects.

**Contents:**
 - Client/Server Simulation
 - DMV Simulation
 - Memory/CPU Simulation
 - Internet Simulation
