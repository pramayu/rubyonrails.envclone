Academic Projects
=================

This Repository contains all of my Academic Projects. They have been categorized by Language.

Contents:
---------
 - **C/C++**:
    - Client/Server Simulation
    - DMV Simulation
    - Memory/CPU Simulation
 - **C#/.NET**:
    - Contact Manager
 - **Java**:
    - Generic Best-First Search
    - Constraint Satisfaction
    - Knowledge Representation
    - Probabilistic Reasoning

***Note***: If you see a Directory not is not listed in the Contents, that is because the Project is still under construction, and is not meant to be viewed, downloaded, compiled, or ran. However, you're welcome to do any of that stuff.
