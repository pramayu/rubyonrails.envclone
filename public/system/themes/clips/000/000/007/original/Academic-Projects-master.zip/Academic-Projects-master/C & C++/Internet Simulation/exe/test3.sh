Node -D 3 -i 0 -l 20 -n 4 1 2 3 4&
Node -D 3 -i 1 -l 20 -m "11111" -d 4 -n 1 0&
Node -D 0 -i 2 -l 20 -m "22222" -d 4 -n 1 0&
Node -D 0 -i 3 -l 20 -m "33333" -d 4 -n 1 0&
Node -D 3 -i 4 -l 20 -n 1 0
