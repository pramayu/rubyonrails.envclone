//* Description *//
// Title: Domain Value
// Author: Tyler Reed
// Defines a Domain Value Interface for Constrained Variables

//* Package *//
package ConstraintSatisfaction;

//* Interface *//
public interface DomainValue extends Comparable<DomainValue>
{
	public Object getValue();
}