Node -i 0 -l 20 -m "This is a Message" -d 1 -n 1 1 -D 3&
Node -i 1 -l 20 -n 1 0 -D 3&
